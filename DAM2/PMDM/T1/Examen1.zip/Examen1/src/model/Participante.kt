package model

open class Participante(var id : Int, var nombre : String, var plantilla : ArrayList<Jugador?>? = null, var puntos : Int?= null, var presupuesto : Int = 10000000) {
    fun ficharJugador(jugador: Jugador?){
        plantilla!!.add(jugador)
        presupuesto -= jugador!!.valor!!
    }
}