package model

class Fantasy () {
    var jugadores : ArrayList<Jugador> = ArrayList<Jugador>()
    var participantes : ArrayList<Participante> = ArrayList<Participante>()

    fun agregarJugadores(){
        jugadores.add(Jugador(1,"Marc-André ter Stegen", "Portero",3000000, 10))
        jugadores.add(Jugador(2,"Ronald Araújo", "Defensa",4000000, 0))
        jugadores.add(Jugador(3,"Eric García", "Defensa",1000000, 3))
        jugadores.add(Jugador(4,"Pedri", "Mediocentro",5000000, 23))
        jugadores.add(Jugador(5,"Robert Lewandowski", "Delantero",8000000, 15))
        jugadores.add(Jugador(6,"Courtois", "Portero",3000000, 1))
        jugadores.add(Jugador(7,"David Alaba", "Defensa",4000000,5))
        jugadores.add(Jugador(8,"Jesús Vallejo", "Defensa",500000, 10))
        jugadores.add(Jugador(9,"Luka Modric", "Mediocentro",5000000, 5))
        jugadores.add(Jugador(10,"Karim Benzema", "Delantero",8000000,10))
        jugadores.add(Jugador(11,"Ledesma", "Portero",500000,6))
        jugadores.add(Jugador(12,"Juan Cala", "Defensa",300000,3))
        jugadores.add(Jugador(13,"Zaldua", "Defensa",400000,6))
        jugadores.add(Jugador(14,"Alez Fernández", "Mediocentro",700000,9))
        jugadores.add(Jugador(15, "Choco Lozano", "Delantero", 800000,4))
        jugadores.add(Jugador(16,"Rajković", "Portero",300000,3))
        jugadores.add(Jugador(17,"Raíllo", "Defensa",200000,6))
        jugadores.add(Jugador(18,"Maffeo", "Defensa",300000,0))
        jugadores.add(Jugador(19,"Ruiz de Galarreta", "Mediocentro",400000, 7))
        jugadores.add(Jugador(20,"Remiro", "Portero",1000000,4))
        jugadores.add(Jugador(21,"Elustondo", "Defensa",900000,3))
        jugadores.add(Jugador(22,"Zubeldia", "Defensa",800000,5))
        jugadores.add(Jugador(23,"Zubimendi", "Mediocentro",1000000,6))
        jugadores.add(Jugador(24,"Take Kubo", "Delantero", 800000,7))
        jugadores.add(Jugador(25,"Ángel", "Delantero", 300000,4))
    }

    fun ficharJugadorId(idJ : Int, idP : Int) {
        buscarParticipante(idP)!!.ficharJugador(buscarJugador(idJ))
    }

    fun buscarJugador (id : Int) : Jugador?{
        return jugadores.find { jugador -> jugador.id == id }
    }

    fun buscarParticipante(id : Int) : Participante?{
        return participantes.find { participante -> participante.id == id }
    }

    fun agregarParticipante(participante: Participante) {
        participantes.add(participante)
    }

    fun calcularPuntuacion(id: Int){
        var participante = buscarParticipante(id)

        if (participante!!.plantilla!!.filter { jugador -> jugador!!.posicion == "portero" }.size < 1 ){
            println("No tienes portero, no puedes puntuar")
            return
        } else if (participante.plantilla!!.filter { jugador -> jugador!!.posicion == "defensa" }.size < 2){
            println("No tienes dos defensas, no puedes puntuar")
            return
        } else if (participante.plantilla!!.filter { jugador -> jugador!!.posicion == "mediocentro" }.size < 2){
            println("No tienes dos mediocentros, no puedes puntuar")
            return
        } else if (participante.plantilla!!.filter { jugador -> jugador!!.posicion == "delantero" }.size < 1) {
            println("No tienes delantero, no `puedes puntuar")
            return
        } else if (participante.presupuesto < 0 ){
            println("Tienes el presupuesto negativo, no puedes puntuar")
            return
        } else{
            participante.plantilla!!.forEach { jugador -> participante.puntos!!.plus(jugador!!.puntuacion!!) }
        }
    }

    fun verGanador()

}