package model

class Jugador (var id : Int, var nombre : String, var posicion : String?, var valor : Int?, var puntuacion : Int?) {
}