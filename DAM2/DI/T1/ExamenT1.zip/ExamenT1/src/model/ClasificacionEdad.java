package model;

public enum ClasificacionEdad {
    PEGI3, PEGI7, PEGI16, PEGI18
}
