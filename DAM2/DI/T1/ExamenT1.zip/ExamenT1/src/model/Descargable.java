package model;

public interface Descargable {

    int calcularTiempoDescarga(double velocidadInternet);

    double obtenerTamanoGB();

}
