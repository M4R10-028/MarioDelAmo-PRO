package database;

public interface SchemaDB {

    String DB_NAME = "concesionario_ces";
    String TAB_USER = "usuarios";
    String COL_ID = "id";
    String COL_NAME = "nombre";
    String COL_SURNAME = "apellidos";
    String COL_MAIL = "correo";
    String COL_PASS = "password";
    String COL_PROFILE = "perfil";
    String COL_AMOUNT = "ventas";
}
